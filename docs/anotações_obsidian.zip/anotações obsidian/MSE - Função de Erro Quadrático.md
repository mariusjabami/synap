A função de erro quadrático (também chamada de Mean Squared Error – MSE) é responsável por medir o quão distante as previsões do modelo estão dos valores reais.

Matematicamente, ela é definida como:
$$
\text{Loss}(w, b) = \frac{1}{N} \sum_{i=1}^{N} (y_{pred,i} - y_i)^2
$$
y_pred → valor previsto pelo modelo

y → valor real (alvo)

N → número total de amostras


Quanto mais próximo de 0 o erro estiver, melhor o modelo está, pois significa que as previsões estão muito próximas dos valores corretos.
Ela não oscila entre 0 e 1, pois o valor depende da escala dos dados – pode ser maior que 1 se os erros forem grandes.

Essa função pode ser usada de várias formas, dependendo:

Dos tipos de dados de entrada (lineares ou não lineares).

Da complexidade do modelo (quantidade de pesos e termos quadráticos, cúbicos, etc.).

```C++
double loss(double w1, double w2, double b) {
    double total = 0;
    for(int i = 0; i < X.size(); i++) {
        double y_pred = ((X[i] * Z[i] * w1) + (pow(X[i] * Z[i], 2) * w2) + b);
        total += pow((y_pred - y[i]), 2);

    }
    return total / X.size();
}
```

No código mostra a representação de uma MSE medindo a distância dos valores dados e previstos.