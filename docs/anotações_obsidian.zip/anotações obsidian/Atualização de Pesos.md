A atualização de pesos é a etapa onde a rede neural ajusta seus parâmetros (pesos e bias) para tentar reduzir o erro (loss).

🔑 Ideia principal:
Se o gradiente indica a direção de maior aumento da loss, então para minimizar a loss, você move o peso na direção oposta ao gradiente.

A fórmula geral é:
$$
w_{\text{novo}} = w_{\text{antigo}} - \eta \cdot \frac{\partial \text{Loss}}{\partial w}
$$
Onde:

w : peso

η : taxa de aprendizado (learning rate) – controla o tamanho do passo

$$\frac{\partial \text{Loss}}{\partial w}$$: gradiente calculado para esse peso


📌 Explicando:

Se o gradiente é positivo, significa que aumentando o peso aumenta o erro → então diminuímos o peso.

Se o gradiente é negativo, significa que aumentando o peso reduz o erro → então aumentamos o peso.


🔄 Esse processo é repetido várias vezes (épocas), e a cada passo o modelo fica mais próximo da melhor solução.

```C++
w1 -= lr * grad_w1;
w2 -= lr * grad_w2;
b -= lr * grad_b;
```
Simples implementação de uma atualização de pesos e viés na rede