O Gradiente Descendente é um algoritmo de otimização usado para ajustar os pesos de um modelo (por exemplo, em redes neurais ou regressões) com o objetivo de minimizar a função de erro (loss).

Ele funciona de forma iterativa:

1. Calcula a inclinação (gradiente) da função de erro em relação a cada peso do modelo.


2. Atualiza os pesos na direção oposta ao gradiente, pois essa é a direção onde o erro diminui.



A fórmula básica de atualização é:
$$
w = w - \eta \cdot \frac{\partial \text{Loss}}{\partial w}
$$
w → peso do modelo

η (eta) → taxa de aprendizado (learning rate), controla o tamanho do passo

$$\frac{∂Loss}{∂w}$$ → derivada da função de erro em relação ao peso


🔑 Ideia central:
O gradiente indica para onde o erro cresce; portanto, para encontrar o mínimo, devemos seguir na direção contrária. Repetindo esse processo várias vezes (épocas), o modelo vai “descendo a montanha” até encontrar o ponto onde o erro é mínimo.

```C++
double grad_w1 = (loss(w1 + h, w2, b) - loss(w1, w2, b)) / h;
        double grad_w2 = (loss(w1, w2 + h, b) - loss(w1, w2, b)) / h;
        double grad_b = (loss(w1, w2, h + b) - loss(w1, w2, b)) / h;

```

No código vemos uma representação de uma rede ajustando 3 gradientes, pesos e viés 