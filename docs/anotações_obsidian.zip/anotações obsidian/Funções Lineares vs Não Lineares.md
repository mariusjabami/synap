1️⃣ Funções Lineares

Definição: Uma função é linear quando a variação da saída é proporcional à variação da entrada.

Fórmula Geral:


$$f(x) = w \cdot x + b$$

 → peso (controla a inclinação da reta)

 → viés/bias (desloca a reta para cima ou para baixo)

Características:

O gráfico é sempre uma reta.

Existe uma única inclinação.

Não consegue aprender relações complexas.


Exemplo:


$$f(x) = 2x + 1$$

Se , $$x=2$$

A saída cresce sempre na mesma proporção.



---

2️⃣ Funções Não Lineares

Definição: Uma função é não linear quando a relação entre entrada e saída não é proporcional ou não pode ser representada por uma única reta.

Fórmula Geral:
Pode ter termos quadráticos, cúbicos, multiplicação entre variáveis ou funções mais complexas:


$$f(x) = w_2 \cdot x^2 + w_1 \cdot x + b$$

O gráfico pode ter curvaturas (parábolas, ondas, etc.).

Permite que modelos capturem padrões complexos.

Essencial em redes neurais para resolver problemas que não são apenas “reta de melhor ajuste”.

Exemplo:


$$f(x) = x^2 + 2x + 1$$

Se , $$x^2$$

O gráfico é uma parábola, não uma linha reta.



---

3️⃣ Na Rede Neural

Uma rede só com funções lineares acaba se comportando como uma única reta, mesmo com várias camadas — isso limita o aprendizado.

Ao adicionar funções não lineares (ex.: ReLU, Sigmoid, Tanh), a rede ganha a capacidade de:

Criar curvas nos dados.

Aprender relações complexas.

Modelar funções que não podem ser representadas por uma reta.

---




