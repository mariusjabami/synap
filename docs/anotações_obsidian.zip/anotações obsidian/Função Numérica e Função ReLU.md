Função Numérica é um método convencional para calcular a inclinação de uma função em um dado ponto, sem recorrermos a cálculos crus e precisos. Geralmente utilizado para código

$$
\text{derivate}(f, x) = \frac{f(x + h) - f(x)}{h}, \qquad h \text{ pequeno}
$$


Normalmente o cálculo é feito da seguinte maneira:

Usamos uma função como base, por exemplo:

$$ func(x) = x ²$$
A seguir aplicamos na função numérica:

$$ func( x + h )² - f(x)² $$

Após todo cálculo e subtração, o ponto final é a divisão por h( é o número de aproximação, são os passos que daremos para tentar aproximar o valor da inclinação, normalmente o h é um valor muito pequeno).

Agora é só dividir pela aproximação:

$$
\frac{f(x + h) - f(x)}{h}
$$


# ReLU

ReLu é uma função de ativação em redes neurais. Ela ajuda a cortar valores negativos e deixar passar os positivos.

$$
ReLU(x) =
\begin{cases}
0 & \text{se } x \leq 0 \\
x & \text{se } x > 0
\end{cases}
$$


Isso ajuda a fazer com que os gradientes não desapareçam conforme acontece na função sigmoid.


```C++
#include<iostream>
#include<cmath>
using namespace std;

double derivate(double (*f)(double), double x, double h=1e-10){
    return ( f(x + h) - f(x) ) / h;
}

int main(){
    auto ReLU = [](double x){ return x > 0 ? x : 0; };
    cout << derivate(ReLU, 3) << endl;

}
```

Nesse código a gente usa para calcular a inclinação de um ponto em relação ReLu, se for 1 quer dizer que existe inclinação e isso ativa a rede, se for 0 quer dizer que a reta não tem inclinação no plano (rede não ativa).

Verificar artigo para mais aprofundamento.

https://www.datacamp.com/pt/blog/rectified-linear-unit-relu